// App.js - Main App component using React.createElement instead of JSX
import React from 'react';
import LogRobinApp from './LogRobinApp';

function App() {
  return React.createElement(
    'div', 
    { className: 'App' },
    React.createElement(LogRobinApp, null)
  );
}

export default App;