// - Service for communicating with the LogRobin++ backend
import React from 'react';

/**
 * API service for communicating with the LogRobin++ backend
 */
class LogRobinAPIService {
  constructor(baseURL = 'http://localhost:3001/api') {
    this.baseURL = baseURL;
  }

  /**
   * Check if the backend service is available
   * @returns {Promise<Object>} Health status
   */
  async checkHealth() {
    try {
      const response = await fetch(`${this.baseURL}/health`);
      if (!response.ok) {
        throw new Error('Backend service returned error status');
      }
      return await response.json();
    } catch (error) {
      console.error('Health check failed:', error);
      throw new Error('Backend service unavailable');
    }
  }

  /**
   * Execute the LogRobin++ protocol
   * @param {Object} config - Protocol configuration
   * @param {Object} proverInput - Prover's input
   * @returns {Promise<Object>} Protocol execution result
   */
  async executeProtocol(config, proverInput) {
    try {
      // Validate config
      if (!config.B || !config.ninputs || !config.nmuls || !config.fieldModulus) {
        throw new Error('Invalid configuration parameters');
      }

      // Validate prover input
      if (proverInput.id === undefined || !Array.isArray(proverInput.witness)) {
        throw new Error('Invalid prover input parameters');
      }

      const response = await fetch(`${this.baseURL}/execute`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ config, proverInput }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Protocol execution failed');
      }

      return await response.json();
    } catch (error) {
      console.error('Protocol execution failed:', error);
      throw error;
    }
  }
}

export default LogRobinAPIService;