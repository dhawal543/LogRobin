// LogRobinApp.js - Main LogRobin++ component using React.createElement instead of JSX
// Regular CSS version (no Tailwind) - Verification details removed
import React, { useState, useEffect } from 'react';
import LogRobinAPIService from './apiService';

const apiService = new LogRobinAPIService();

function LogRobinApp() {
  // State variables using useState hooks
  const [config, setConfig] = useState({
    B: 4, // Number of branches
    ninputs: 3, // Number of inputs per circuit
    nmuls: 5, // Number of multiplications per circuit
    fieldModulus: "101", // Field modulus (as string to handle BigInt)
    logLevel: "info"
  });


  const handleWitnessChange = (index, value) => {
    // Make sure value is a valid numeric string
    const validValue = value.replace(/[^0-9]/g, '');
    
    const newWitness = [...proverInput.witness];
    newWitness[index] = validValue || "0";
    setProverInput({
      ...proverInput,
      witness: newWitness
    });
  };
  
  const [proverInput, setProverInput] = useState({
    id: 2, // Active branch
    witness: ["0", "1", "1"] // Sum = 2 mod 101
    // Witness values as strings
  });

  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [logOutput, setLogOutput] = useState([]);
  const [backendStatus, setBackendStatus] = useState('unknown');

  // Check backend health on component mount
  useEffect(() => {
    checkBackendHealth();
  }, []);

  // Check backend server health
  const checkBackendHealth = async () => {
    try {
      await apiService.checkHealth();
      setBackendStatus('online');
      addLog('info', 'Connected to LogRobin++ backend server');
    } catch (error) {
      setBackendStatus('offline');
      addLog('error', 'Cannot connect to backend server. Using simulation mode.');
    }
  };

  // Handle config change
  const handleConfigChange = (e) => {
    const { name, value } = e.target;
    setConfig({
      ...config,
      [name]: name === "fieldModulus" ? value : parseInt(value, 10)
    });
  };

  // Handle prover ID change
  // Handle prover ID change
const handleIdChange = (e) => {
  setProverInput({
    ...proverInput,
    id: parseInt(e.target.value, 10)
  });
};
// In LogRobinApp.js


  // Handle adding a witness input
  const addWitnessInput = () => {
    setProverInput({
      ...proverInput,
      witness: [...proverInput.witness, "0"]
    });
  };

  // Handle removing a witness input
  const removeWitnessInput = (index) => {
    const newWitness = [...proverInput.witness];
    newWitness.splice(index, 1);
    setProverInput({
      ...proverInput,
      witness: newWitness
    });
  };

  // Update witness array size based on ninputs
  const updateWitnessSize = () => {
    const currentLength = proverInput.witness.length;
    const targetLength = config.ninputs;
    
    if (currentLength < targetLength) {
      // Add more witness inputs
      const newWitness = [...proverInput.witness];
      for (let i = currentLength; i < targetLength; i++) {
        newWitness.push("0");
      }
      setProverInput({
        ...proverInput,
        witness: newWitness
      });
    } else if (currentLength > targetLength) {
      // Remove excess witness inputs
      setProverInput({
        ...proverInput,
        witness: proverInput.witness.slice(0, targetLength)
      });
    }
  };

  // Execute the protocol
  const executeProtocol = async () => {
    setLoading(true);
    setLogOutput([]);
    setResults(null);
    
    try {
      addLog('info', 'Starting LogRobin++ protocol execution');
      
      // Basic validation before sending to server
      if (proverInput.id < 0 || proverInput.id >= config.B) {
        throw new Error(`Branch ID must be between 0 and ${config.B - 1}`);
      }
      
      if (proverInput.witness.length !== config.ninputs) {
        throw new Error(`Witness must have exactly ${config.ninputs} elements`);
      }
      
      // If backend is online, use it
      if (backendStatus === 'online') {
        addLog('info', 'Sending request to backend server');
        
        const result = await apiService.executeProtocol(config, proverInput);
        
        // Process server logs
        if (result.logs) {
          result.logs.forEach(log => {
            // Parse log level from the log string if possible
            let level = 'info';
            if (log.includes('[ERROR]')) level = 'error';
            else if (log.includes('[WARN]')) level = 'warn';
            else if (log.includes('[INFO]')) level = 'info';
            else if (log.includes('[DEBUG]')) level = 'debug';
            
            addLog(level, log);
          });
        }
        
        setResults(result);
        addLog('info', `Protocol execution ${result.success ? 'succeeded' : 'failed'}`);
      } else {
        // Use simulation mode (similar to original implementation)
        addLog('warn', 'Using simulation mode (backend server unavailable)');
        
        // Simulate backend processing
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const activeId = proverInput.id;
        
        // Simple circuit satisfaction check - sum mod fieldModulus = branch id
        let witnessSum = proverInput.witness.reduce((sum, val) => {
          const bigSum = BigInt(sum);
          const bigVal = BigInt(val);
          const bigMod = BigInt(config.fieldModulus);
          return (bigSum + bigVal) % bigMod;
        }, 0n);
        
        const expectedMod = BigInt(activeId) % BigInt(config.fieldModulus);
        const satisfied = witnessSum === expectedMod;
        
        addLog('debug', `Active branch evaluation: ${satisfied ? 'PASS' : 'FAIL'}`);
        addLog('debug', `Witness sum: ${witnessSum}, expected mod: ${expectedMod}`);
        
        if (!satisfied) {
          throw new Error(`Witness does not satisfy active branch. Sum mod ${config.fieldModulus} should equal ${activeId % parseInt(config.fieldModulus)}`);
        }
        
        addLog('debug', 'Simulating VOLE correlation generation');
        addLog('debug', 'Simulating witness commitments');
        addLog('debug', 'Simulating multiplication triple evaluation');
        addLog('debug', 'Simulating zero-membership subprotocol');
        addLog('debug', 'Simulating affine correlation subprotocol');
        addLog('info', 'Performing final verification');
        
        // Since simulation passed all checks, we can simulate success
        const simulationResult = {
          success: true,
          details: {
            batchedVerification: true,
            zeroMembershipVerification: true,
            affineCorrelationVerification: true
          },
          executionTime: Math.floor(Math.random() * 100) + 50
        };
        
        setResults(simulationResult);
        addLog('info', 'Final verification result: ACCEPT');
      }
    } catch (error) {
      addLog('error', `Protocol execution failed: ${error.message}`);
      setResults({
        success: false,
        error: error.message
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Add a log entry
  const addLog = (level, message) => {
    // Only add logs that match the configured level
    const levels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3,
      trace: 4
    };
    
    if (levels[level] <= levels[config.logLevel]) {
      setLogOutput(prev => [...prev, { 
        timestamp: new Date().toISOString(),
        level,
        message
      }]);
    }
  };


  // Add this function to your component


  // Create elements for rendering witness inputs
  const renderWitnessInputs = () => {
    return proverInput.witness.map((value, index) => {
      return React.createElement('div', { key: index, className: 'witness-row' },
        React.createElement('input', {
          type: 'text',
          value: value,
          onChange: (e) => handleWitnessChange(index, e.target.value),
          className: 'witness-input',
          placeholder: `Input ${index + 1}`
        }),
        proverInput.witness.length > 1 ? 
          React.createElement('button', {
            onClick: () => removeWitnessInput(index),
            className: 'witness-remove',
            'aria-label': 'Remove input'
          }, '✕') : null
      );
    });
  };

  // Create elements for rendering log outputs
  const renderLogs = () => {
    return logOutput.length > 0 ? 
      logOutput.map((log, index) => {
        const logClass = `log-entry log-${log.level}`;
        
        return React.createElement('div', { key: index, className: logClass },
          React.createElement('span', { className: 'log-time' }, 
            `[${log.timestamp.split('T')[1].split('.')[0]}] `),
          React.createElement('span', { className: 'log-level' }, 
            `[${log.level}]`),
          ` ${log.message}`
        );
      }) :
      React.createElement('div', { className: 'text-placeholder' }, 'No logs yet');
  };

  // Main render function using React.createElement
  return React.createElement('div', { className: 'container' },
    // Header
    React.createElement('header', { className: 'header' },
      React.createElement('h1', {}, 'LogRobin++ Protocol Demonstrator'),
      React.createElement('p', {}, 'Interactive frontend for the LogRobin++ zero-knowledge protocol'),
      
      React.createElement('div', { 
        className: `status-indicator status-${backendStatus}`
      },
        React.createElement('span', { 
          className: `status-dot dot-${backendStatus}`
        }),
        backendStatus === 'online' 
          ? 'Backend Connected' 
          : backendStatus === 'offline' 
            ? 'Backend Disconnected (Simulation Mode)'
            : 'Checking Backend Status...'
      )
    ),
    
    // Main content grid
    React.createElement('div', { className: 'grid' },
      // Left column - Configuration and Input
      React.createElement('div', {},
        // Protocol Configuration
        React.createElement('div', { className: 'card' },
          React.createElement('h2', {}, 'Protocol Configuration'),
          
          React.createElement('div', { className: 'form-grid' },
            // Number of Branches
            React.createElement('div', { className: 'form-group' },
              React.createElement('label', { className: 'form-label' }, 'Number of Branches (B)'),
              React.createElement('input', {
                type: 'number',
                name: 'B',
                min: '2',
                value: config.B,
                onChange: handleConfigChange,
                className: 'form-input'
              })
            ),
            
            // Inputs per Circuit
            React.createElement('div', { className: 'form-group' },
              React.createElement('label', { className: 'form-label' }, 'Inputs per Circuit'),
              React.createElement('input', {
                type: 'number',
                name: 'ninputs',
                min: '1',
                value: config.ninputs,
                onChange: (e) => {
                  handleConfigChange(e);
                  setTimeout(updateWitnessSize, 0);
                },
                className: 'form-input'
              })
            ),
            
            // Multiplications per Circuit
            React.createElement('div', { className: 'form-group' },
              React.createElement('label', { className: 'form-label' }, 'Multiplications per Circuit'),
              React.createElement('input', {
                type: 'number',
                name: 'nmuls',
                min: '1',
                value: config.nmuls,
                onChange: handleConfigChange,
                className: 'form-input'
              })
            ),
            
            // Field Modulus
            React.createElement('div', { className: 'form-group' },
              React.createElement('label', { className: 'form-label' }, 'Field Modulus'),
              React.createElement('input', {
                type: 'text',
                name: 'fieldModulus',
                value: config.fieldModulus,
                onChange: handleConfigChange,
                className: 'form-input'
              }),
              React.createElement('p', { className: 'form-hint' }, 
                'Recommended: 101, 1021, 10007, etc.')
            ),
            
            // Log Level
            React.createElement('div', { className: 'form-group' },
              React.createElement('label', { className: 'form-label' }, 'Log Level'),
              React.createElement('select', {
                name: 'logLevel',
                value: config.logLevel,
                onChange: (e) => setConfig({...config, logLevel: e.target.value}),
                className: 'form-select'
              },
                React.createElement('option', { value: 'error' }, 'Error'),
                React.createElement('option', { value: 'warn' }, 'Warning'),
                React.createElement('option', { value: 'info' }, 'Info'),
                React.createElement('option', { value: 'debug' }, 'Debug'),
                React.createElement('option', { value: 'trace' }, 'Trace')
              )
            )
          )
        ),
        
        // Prover Input
        React.createElement('div', { className: 'card' },
          React.createElement('h2', {}, 'Prover Input'),
          
          // Active Branch ID
          React.createElement('div', { className: 'form-group' },
            React.createElement('label', { className: 'form-label' }, 'Active Branch ID'),
            React.createElement('input', {
              type: 'number',
              min: '0',
              max: config.B - 1,
              value: proverInput.id,
              onChange: handleIdChange,
              className: 'form-input'
            }),
            React.createElement('p', { className: 'form-hint' }, 
              `Must be between 0 and ${config.B - 1}`)
          ),
          
          // Witness Inputs
          React.createElement('div', { className: 'form-group' },
            React.createElement('label', { className: 'form-label' }, 'Witness Inputs'),
            React.createElement('p', { className: 'form-hint' },
              `For this demo, the circuit satisfaction condition is: sum(witness) ≡ branch_id (mod ${config.fieldModulus})`
            ),
            
            React.createElement('div', { className: 'witness-container' },
              ...renderWitnessInputs()
            ),
            
            proverInput.witness.length < config.ninputs ?
              React.createElement('button', {
                onClick: addWitnessInput,
                className: 'add-witness-btn'
              }, '+ Add Input') : null
          ),
          
          // Execute Button
          React.createElement('button', {
            onClick: executeProtocol,
            disabled: loading,
            className: `btn btn-primary`
          }, loading ? 'Executing Protocol...' : 'Execute Protocol')
        )
      ),
      
      // Right column - Results and Logs
      React.createElement('div', {},
        // Protocol Results
        React.createElement('div', { className: 'card' },
          React.createElement('h2', {}, 'Protocol Results'),
          
          results ? 
            React.createElement('div', {},
              React.createElement('div', { 
                className: `result-panel ${results.success ? 'result-success' : 'result-error'}`
              },
                React.createElement('div', { className: 'result-header' },
                  React.createElement('span', { 
                    className: `result-icon ${results.success ? 'success-icon' : 'error-icon'}`
                  }, results.success ? '✓' : '✗'),
                  React.createElement('h3', { className: 'result-title' },
                    results.success ? 'Protocol Execution Successful' : 'Protocol Execution Failed'
                  )
                ),
                results.error ? 
                  React.createElement('p', {}, results.error) :
                  React.createElement('p', {}, `Execution time: ${results.executionTime}ms`)
              )
              // Verification details section has been removed here
            ) : 
            React.createElement('div', { className: 'text-placeholder' },
              loading ? 'Processing...' : 'Execute the protocol to see results'
            )
        ),
        
        // Log Output
        React.createElement('div', { className: 'card' },
          React.createElement('h2', {}, 'Protocol Log'),
          
          React.createElement('div', { className: 'log-container' },
            renderLogs()
          )
        )
      )
    )
  );
}

export default LogRobinApp;